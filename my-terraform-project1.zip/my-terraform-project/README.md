# my-terraform-project

Standard, environment-aware Terraform project structure for provisioning AWS
infrastructure (VPC, subnets, NAT/IGW) using reusable modules and
per-environment configuration.

## Project Structure

```
my-terraform-project/
├── main.tf                    # Root module - wires together child modules
├── variables.tf                # Root input variables
├── outputs.tf                  # Root output values
├── providers.tf                 # Provider configuration (AWS)
├── versions.tf                  # Required Terraform & provider versions
├── backend.tf                   # Backend placeholder (configured per-env)
├── modules/
│   └── vpc/
│       ├── main.tf              # VPC, subnets, IGW, NAT, route tables
│       ├── variables.tf         # Module input variables
│       ├── outputs.tf           # Module output values
│       └── versions.tf          # Module version constraints
├── environments/
│   ├── dev/
│   │   ├── terraform.tfvars     # Dev-specific variable values
│   │   └── backend.tf           # Dev remote state backend config
│   ├── staging/
│   │   ├── terraform.tfvars     # Staging-specific variable values
│   │   └── backend.tf           # Staging remote state backend config
│   └── prod/
│       ├── terraform.tfvars     # Prod-specific variable values
│       └── backend.tf           # Prod remote state backend config
└── README.md                    # This file
```

## File Purposes

| File | Purpose |
|---|---|
| `main.tf` | Main configuration file. Contains all the resources (via module calls). |
| `variables.tf` | Input variables for the configuration. Makes values reusable and configurable. |
| `outputs.tf` | Output values exported after `terraform apply`. |
| `providers.tf` | Provider configuration. Defines the cloud provider and credentials/region. |
| `versions.tf` | Specifies required Terraform version and provider versions. |
| `modules/vpc/` | Reusable module for VPC infrastructure. Self-contained with its own main/variables/outputs/versions. |
| `environments/<env>/terraform.tfvars` | Environment-specific variable values (CIDR ranges, region, etc). |
| `environments/<env>/backend.tf` | Environment-specific remote state backend settings (S3 bucket, key, DynamoDB lock table). |
| `backend.tf` | Optional root backend stub; actual backend values are supplied per-environment at `init` time. |

## Prerequisites

- [Terraform](https://developer.hashicorp.com/terraform/downloads) >= 1.6.0
- AWS CLI configured with valid credentials (`aws configure`)
- An S3 bucket + DynamoDB table for remote state locking (per environment),
  or update `backend.tf` files to match your chosen backend.

## Usage

Each environment is initialized separately so it uses its own backend and
variable values.

### 1. Initialize for an environment

```bash
terraform init -backend-config=environments/dev/backend.tf
```

### 2. Plan

```bash
terraform plan -var-file=environments/dev/terraform.tfvars
```

### 3. Apply

```bash
terraform apply -var-file=environments/dev/terraform.tfvars
```

### Switching environments

Re-run `init` with `-reconfigure` when switching between environments so
Terraform points at the correct backend:

```bash
terraform init -reconfigure -backend-config=environments/staging/backend.tf
terraform plan -var-file=environments/staging/terraform.tfvars
```

> Tip: for larger teams, consider Terraform Workspaces or separate state
> per environment (as modeled here) — this layout uses the latter, which is
> generally safer for prod isolation.

## Adding a New Module

1. Create a new folder under `modules/<module-name>/`.
2. Add `main.tf`, `variables.tf`, `outputs.tf`, and `versions.tf` inside it.
3. Reference it from the root `main.tf` via a `module` block.

## Conventions

- All resources are tagged with `Project`, `Environment`, and `ManagedBy` by
  default (see `providers.tf`).
- Variable and resource names use `snake_case`.
- Sensitive values (credentials, secrets) should never be committed —
  use environment variables, `TF_VAR_*`, or a secrets manager instead.
- Run `terraform fmt -recursive` and `terraform validate` before committing.

## License

Internal use / adapt as needed for your organization.
