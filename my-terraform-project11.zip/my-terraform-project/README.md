# my-terraform-project

Standard, environment-aware Terraform project structure for provisioning AWS
infrastructure — VPC, EC2, S3 + CloudFront, and EKS — using reusable modules
and per-environment configuration.

## Project Structure

```
my-terraform-project/
├── main.tf                      # Root module - wires together child modules
├── variables.tf                  # Root input variables
├── outputs.tf                    # Root output values
├── providers.tf                   # Provider configuration (AWS)
├── versions.tf                    # Required Terraform & provider versions
├── backend.tf                     # Backend placeholder (configured per-env)
├── modules/
│   ├── vpc/
│   │   ├── main.tf                # VPC, subnets, IGW, NAT, route tables
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   └── versions.tf
│   ├── ec2/
│   │   ├── main.tf                # Security group + EC2 instance(s)
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   └── versions.tf
│   ├── s3/
│   │   ├── main.tf                # Encrypted, versioned, private S3 bucket
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   └── versions.tf
│   ├── cloudfront/
│   │   ├── main.tf                # CDN distribution + OAC + bucket policy
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   └── versions.tf
│   └── eks/
│       ├── main.tf                # EKS cluster + managed node group + IAM
│       ├── variables.tf
│       ├── outputs.tf
│       └── versions.tf
├── environments/
│   ├── dev/
│   │   ├── terraform.tfvars       # Dev-specific variable values
│   │   └── backend.tf             # Dev remote state backend config
│   ├── staging/
│   │   ├── terraform.tfvars       # Staging-specific variable values
│   │   └── backend.tf             # Staging remote state backend config
│   └── prod/
│       ├── terraform.tfvars       # Prod-specific variable values
│       └── backend.tf             # Prod remote state backend config
└── README.md                      # This file
```

## Modules

| Module | Purpose |
|---|---|
| `vpc` | VPC, public/private subnets, internet gateway, NAT gateway, route tables. |
| `ec2` | Security group + one or more EC2 instances (latest Amazon Linux 2023 AMI) in the public subnets. |
| `s3` | Private, encrypted, versioned S3 bucket used as a static asset origin. |
| `cloudfront` | CloudFront distribution in front of the S3 bucket via Origin Access Control (OAC), with a bucket policy restricting reads to that distribution. |
| `eks` | EKS control plane + one managed node group, with the cluster/node IAM roles and policy attachments, deployed into the private subnets. |

## File Purposes (root)

| File | Purpose |
|---|---|
| `main.tf` | Main configuration file. Calls each module (vpc, ec2, s3, cloudfront, eks). |
| `variables.tf` | Input variables for the configuration, grouped by module. |
| `outputs.tf` | Output values exported after `terraform apply`. |
| `providers.tf` | Provider configuration. Defines the cloud provider and credentials/region. |
| `versions.tf` | Specifies required Terraform version and provider versions. |
| `environments/<env>/terraform.tfvars` | Environment-specific variable values (CIDR ranges, instance sizes, node counts, etc). |
| `environments/<env>/backend.tf` | Environment-specific remote state backend settings (S3 bucket, key, DynamoDB lock table). |
| `backend.tf` | Optional root backend stub; actual backend values are supplied per-environment at `init` time. |

## Prerequisites

- [Terraform](https://developer.hashicorp.com/terraform/downloads) >= 1.6.0
- AWS CLI configured with valid credentials (`aws configure`)
- An S3 bucket + DynamoDB table for remote state locking (per environment),
  or update `backend.tf` files to match your chosen backend.
- `kubectl` and the AWS CLI's `aws eks update-kubeconfig` if you plan to
  interact with the EKS cluster after apply.

## Usage

Each environment is initialized separately so it uses its own backend and
variable values.

### 1. Initialize for an environment

```bash
terraform init -backend-config=environments/dev/backend.tf
```

### 2. Plan

```bash
terraform plan -var-file=environments/dev/terraform.tfvars
```

### 3. Apply

```bash
terraform apply -var-file=environments/dev/terraform.tfvars
```

### Switching environments

Re-run `init` with `-reconfigure` when switching between environments so
Terraform points at the correct backend:

```bash
terraform init -reconfigure -backend-config=environments/staging/backend.tf
terraform plan -var-file=environments/staging/terraform.tfvars
```

### Connecting to the EKS cluster after apply

```bash
aws eks update-kubeconfig --name my-terraform-project-dev-eks --region us-east-1
kubectl get nodes
```

> Tip: for larger teams, consider Terraform Workspaces or separate state
> per environment (as modeled here) — this layout uses the latter, which is
> generally safer for prod isolation.

## Adding a New Module

1. Create a new folder under `modules/<module-name>/`.
2. Add `main.tf`, `variables.tf`, `outputs.tf`, and `versions.tf` inside it.
3. Reference it from the root `main.tf` via a `module` block.

## Notes on Included Resources

- **EC2** instances are placed in **public** subnets and get a public IP by
  default (via the VPC module's `map_public_ip_on_launch`). Adjust
  `ec2_allowed_ssh_cidrs` to lock down SSH access instead of leaving it open.
- **S3 + CloudFront**: the bucket has all public access blocked; only the
  CloudFront distribution (via OAC + bucket policy) can read from it.
- **EKS** node group and control plane run in the **private** subnets;
  the cluster API endpoint is public by default (`endpoint_public_access`)
  for simplicity — restrict or disable this for production.
- Instance sizes / node counts scale up from `dev` → `staging` → `prod` in
  the provided `terraform.tfvars` files; adjust to your actual workload and
  budget.

## Conventions

- All resources are tagged with `Project`, `Environment`, and `ManagedBy` by
  default (see `providers.tf`).
- Variable and resource names use `snake_case`.
- Sensitive values (credentials, secrets) should never be committed —
  use environment variables, `TF_VAR_*`, or a secrets manager instead.
- Run `terraform fmt -recursive` and `terraform validate` before committing.

## License

Internal use / adapt as needed for your organization.
